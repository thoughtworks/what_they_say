function getCurrentLanguague(language) {
    var defaultLanguage = "pt-BR"
  
    return !language ? defaultLanguage : language
  }

  function addClass(view, className) {
    console.log(view)
    view.classList.add(className)
    return div
  }