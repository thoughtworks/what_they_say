function setupRecognition (recognition) {
    recognition.continuous = false;
    recognition.interimResults = true;
    return recognition
}